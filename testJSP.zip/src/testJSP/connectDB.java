package testJSP;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.text.SimpleDateFormat;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public enum connectDB {
	INSTANCE; //�̱��� �������� ����ϱ� ���� �ڵ�
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	ResultSet rs2 = null;
	String sql = "";
	String sql2 = "";
	String returns = "";
	String return2 = "";
	
	// �����ͺ��̽��� ����ϱ� ���� �ڵ尡 ����ִ� �޼���
	public String joinDB(String id, String pwd, String nickname) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String joindate = sdf.format(date);
		int usernum = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// ��� ����
            // DriverManager.getConnection"jdbcUrl", "DBId", "DBPw");�� �����
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/smartcloset?useUnicode=true&"
					+ "characterEncoding=UTF8&serverTimezone=UTC", "root", "1103");
			sql = "select id from userinfo where id = ?;";// ��ȸ
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery(); //rs�� sql�� ���ప ����
			sql2 = "select count(*) from userinfo;"; //userinfo Table�� �� ����
			pstmt = conn.prepareStatement(sql2);
			rs2 = pstmt.executeQuery();
			if(rs2.next()) 
				usernum = rs2.getInt("count(*)") + 1;
			
			if (rs.next()) {
				if (rs.getString("id").equals(id)) { //���̵� �ߺ�
					returns = "id";
				}
			} else {
				// ȸ�������� ������ ���
				sql2 = "insert into userinfo values(?,?,?,?,?);"; // ����
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setString(1, id);
				pstmt2.setString(2, pwd);
				pstmt2.setString(3, nickname);
				pstmt2.setInt(4, usernum);
				pstmt2.setString(5, joindate);
				pstmt2.executeUpdate();
				returns = "ok";
			}
		} catch (Exception e) {
			e.printStackTrace();
			returns = e.toString();
		} finally {
			if (rs != null)try {rs.close();} catch (SQLException ex) {}
			if (rs2 != null)try {rs2.close();} catch (SQLException ex) {}
			if (pstmt2 != null)try {pstmt2.close();	} catch (SQLException ex) {}
			if (pstmt != null)try {pstmt.close();} catch (SQLException ex) {}
			if (conn != null)try {conn.close();	} catch (SQLException ex) {}
			
		}
		return returns;
	}
	
	public String loginDB(String id, String pwd) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// ��� ����
            // DriverManager.getConnection"jdbcUrl", "DBId", "DBPw");�� �����
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/smartcloset?useUnicode=true&"
					+ "characterEncoding=UTF8&serverTimezone=UTC", "root", "1103");
			sql = "select id, password from userinfo where id = '"+ id +"';";// ��ȸ
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getString("id").equals(id) && rs.getString("password").equals(pwd)) {
					return2 = "true";// �α��� ����
				} else {
					return2 = "false"; // ���̵� Ȥ�� ��й�ȣ Ʋ��
				}
			} else {
				return2 = "noId"; // ���̵� �Ǵ� ��й�ȣ ���� X
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (rs != null)try {rs.close();} catch (SQLException ex) {}
			if (pstmt != null)try {pstmt.close();} catch (SQLException ex) {}
			if (conn != null)try {conn.close();} catch (SQLException ex) {}
			
		}
		return return2;
	}
	
	public JSONArray makeArray(ResultSet rs1, ResultSet rs2) {
		JSONArray jArray = new JSONArray();
		int i = 0;
		try {
			while(rs1.next()) {
				JSONObject jObject = new JSONObject();
				String updown = rs1.getString("updown");
				String type = rs1.getString("type");
				String thickness = rs1.getString("thickness");
				jObject.put("updown", updown);
				jObject.put("type", type);
				jObject.put("thickness", thickness);
				if(jObject != null) jArray.add(i, jObject);
				i += 1;
				
			}
			while(rs2.next()) {
				JSONObject jObject = new JSONObject();
				String updown = rs2.getString("updown");
				String type = rs2.getString("type");
				String thickness = rs2.getString("thickness");
				jObject.put("updown", updown);
				jObject.put("type", type);
				jObject.put("thickness", thickness);
				if(jObject != null) jArray.add(i, jObject);
				i += 1;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jArray;
	}
	public JSONArray makeArray(ResultSet rs1) {
		JSONArray jArray = new JSONArray();
		int i = 0;
		try {
			while(rs1.next()) {
				JSONObject jObject = new JSONObject();
				String updown = rs1.getString("updown");
				String type = rs1.getString("type");
				String thickness = rs1.getString("thickness");
				jObject.put("updown", updown);
				jObject.put("type", type);
				jObject.put("thickness", thickness);
				if(jObject != null) jArray.add(i, jObject);
				i += 1;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jArray;
	}

	
	public JSONObject getcloth(String season, String output) {
		int season2 = Integer.parseInt(season);
		JSONObject jsonMain = new JSONObject();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// ��� ����
            // DriverManager.getConnection"jdbcUrl", "DBId", "DBPw");�� �����
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/smartcloset?useUnicode=true&"
					+ "characterEncoding=UTF8&serverTimezone=UTC", "root", "1103");
			
			if (season2 == 0) {
				sql2 = "select * from outputdb;";
				sql = "select * from clothdb;";
				pstmt = conn.prepareStatement(sql);
				pstmt2 = conn.prepareStatement(sql2);
				rs = pstmt.executeQuery();
				rs2 = pstmt2.executeQuery();
				jsonMain.put("ListfromSQL", makeArray(rs, rs2));
				
			} else if (season2 == 1) {
				sql2 = "select * from outputdb where thickness = '1';"; //�ܿ����
				sql = "select * from clothdb where thickness <= '3';";
				pstmt = conn.prepareStatement(sql);
				pstmt2 = conn.prepareStatement(sql2);
				rs = pstmt.executeQuery();
				rs2 = pstmt2.executeQuery();
				jsonMain.put("ListfromSQL", makeArray(rs, rs2));
				
			} else if (season2 == 2) {
				sql2 = "select * from outputdb where thickness = '2';"; //�β��� ���
				sql = "select * from clothdb where thickness = '2' or thickness = '3'";
				pstmt = conn.prepareStatement(sql);
				pstmt2 = conn.prepareStatement(sql2);
				rs = pstmt.executeQuery();
				rs2 = pstmt2.executeQuery();
				jsonMain.put("ListfromSQL", makeArray(rs, rs2));
				
			} else if (season2 == 3) {
				if (output == "true") {
					sql2 = "select * from outputdb where thickness <= '3';"; //�߰�, ���� ���
					sql = "select * from clothdb where thickness = '3' or thickness = '4'";
					pstmt = conn.prepareStatement(sql);
					pstmt2 = conn.prepareStatement(sql2);
					rs = pstmt.executeQuery();
					rs2 = pstmt2.executeQuery();
					jsonMain.put("ListfromSQL", makeArray(rs, rs2));
					
				} else {
					sql = "select * from clothdb where thickness = '2'";
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					jsonMain.put("ListfromSQL", makeArray(rs));
					
				}
				
			} else if (season2 == 4) {
				if (output == "true") {
					sql2 = "select * from outputdb where thickness = '4';"; //���� ���
					sql = "select * from clothdb where thickness = '4' or thickness = '5'";
					pstmt = conn.prepareStatement(sql);
					pstmt2 = conn.prepareStatement(sql2);
					rs = pstmt.executeQuery();
					rs2 = pstmt2.executeQuery();
					jsonMain.put("ListfromSQL", makeArray(rs, rs2));
					
				} else {
					sql = "select * from clothdb where thickness = '3'";
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					jsonMain.put("ListfromSQL", makeArray(rs));
				}
				
			} else { //����
				sql = "select * from clothdb where thickness = '4' or thickness = '5'";
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				jsonMain.put("ListfromSQL", makeArray(rs));
					
			}
						
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (rs != null) try {rs.close();} catch (SQLException ex) {}
			if (rs != null)try {rs.close();} catch (SQLException ex) {}
			if (pstmt != null)try {pstmt.close();} catch (SQLException ex) {}
			if (conn != null)try {conn.close();} catch (SQLException ex) {}
			
			
		}
		
		return jsonMain;
	}

}
